/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sanyam_agrawal1
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

public class ScheduleQueries {
    private static Connection connection;
    private static PreparedStatement addScheduleEntry;
    private static PreparedStatement getScheduleByStudent;
    private static PreparedStatement getScheduledStudentCount;
    private static PreparedStatement getWaitlistedStudentsByClass;
    private static PreparedStatement dropStudentScheduleByCourse;
    private static PreparedStatement dropScheduleByCourse;
    private static PreparedStatement updateScheduleEntry;
    private static ResultSet resultSet;

    public static void addScheduleEntry(ScheduleEntry entry) {
        connection = DBConnection.getConnection();
        try {
            addScheduleEntry = connection.prepareStatement(
                "INSERT INTO schedule (semester, courseCode, studentID, status, timestamp) VALUES (?, ?, ?, ?, ?)"
            );
            addScheduleEntry.setString(1, entry.getSemester());
            addScheduleEntry.setString(2, entry.getCourseCode());
            addScheduleEntry.setString(3, entry.getStudentID());
            addScheduleEntry.setString(4, entry.getStatus());
            addScheduleEntry.setTimestamp(5, entry.getTimestamp());
            addScheduleEntry.executeUpdate();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }

    public static ArrayList<ScheduleEntry> getScheduleByStudent(String semester, String studentID) {
        connection = DBConnection.getConnection();
        ArrayList<ScheduleEntry> schedule = new ArrayList<>();
        try {
            getScheduleByStudent = connection.prepareStatement(
                "SELECT * FROM schedule WHERE semester = ? AND studentID = ?"
            );
            getScheduleByStudent.setString(1, semester);
            getScheduleByStudent.setString(2, studentID);
            resultSet = getScheduleByStudent.executeQuery();
            while (resultSet.next()) {
                schedule.add(new ScheduleEntry(
                    resultSet.getString("semester"),
                    resultSet.getString("courseCode"),
                    resultSet.getString("studentID"),
                    resultSet.getString("status"),
                    resultSet.getTimestamp("timestamp")
                ));
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return schedule;
    }

    public static int getScheduledStudentCount(String semester, String courseCode) {
        connection = DBConnection.getConnection();
        int count = 0;
        try {
            getScheduledStudentCount = connection.prepareStatement(
                "SELECT COUNT(*) FROM schedule WHERE semester = ? AND courseCode = ? AND status = 'S'"
            );
            getScheduledStudentCount.setString(1, semester);
            getScheduledStudentCount.setString(2, courseCode);
            resultSet = getScheduledStudentCount.executeQuery();
            if (resultSet.next()) {
                count = resultSet.getInt(1);
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return count;
    }

    public static ArrayList<ScheduleEntry> getWaitlistedStudentsByClass(String semester, String courseCode) {
        connection = DBConnection.getConnection();
        ArrayList<ScheduleEntry> waitlist = new ArrayList<>();
        try {
            getWaitlistedStudentsByClass = connection.prepareStatement(
                "SELECT * FROM schedule WHERE semester = ? AND courseCode = ? AND status = 'W' ORDER BY timestamp"
            );
            getWaitlistedStudentsByClass.setString(1, semester);
            getWaitlistedStudentsByClass.setString(2, courseCode);
            resultSet = getWaitlistedStudentsByClass.executeQuery();
            while (resultSet.next()) {
                waitlist.add(new ScheduleEntry(
                    resultSet.getString("semester"),
                    resultSet.getString("courseCode"),
                    resultSet.getString("studentID"),
                    resultSet.getString("status"),
                    resultSet.getTimestamp("timestamp")
                ));
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return waitlist;
    }

    public static void dropStudentScheduleByCourse(String semester, String studentID, String courseCode) {
        connection = DBConnection.getConnection();
        try {
            dropStudentScheduleByCourse = connection.prepareStatement(
                "DELETE FROM schedule WHERE semester = ? AND studentID = ? AND courseCode = ?"
            );
            dropStudentScheduleByCourse.setString(1, semester);
            dropStudentScheduleByCourse.setString(2, studentID);
            dropStudentScheduleByCourse.setString(3, courseCode);
            dropStudentScheduleByCourse.executeUpdate();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }

    public static void dropScheduleByCourse(String semester, String courseCode) {
        connection = DBConnection.getConnection();
        try {
            dropScheduleByCourse = connection.prepareStatement(
                "DELETE FROM schedule WHERE semester = ? AND courseCode = ?"
            );
            dropScheduleByCourse.setString(1, semester);
            dropScheduleByCourse.setString(2, courseCode);
            dropScheduleByCourse.executeUpdate();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }

    public static void updateScheduleEntry(ScheduleEntry entry) {
        connection = DBConnection.getConnection();
        try {
            updateScheduleEntry = connection.prepareStatement(
                "UPDATE schedule SET status = ?, timestamp = ? WHERE semester = ? AND courseCode = ? AND studentID = ?"
            );
            updateScheduleEntry.setString(1, entry.getStatus());
            updateScheduleEntry.setTimestamp(2, entry.getTimestamp());
            updateScheduleEntry.setString(3, entry.getSemester());
            updateScheduleEntry.setString(4, entry.getCourseCode());
            updateScheduleEntry.setString(5, entry.getStudentID());
            updateScheduleEntry.executeUpdate();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }


    public static ArrayList<StudentEntry> getScheduledStudentsByCourse(String semester, String courseCode) {
        ArrayList<StudentEntry> list = new ArrayList<>();
        try {
            PreparedStatement ps = connection.prepareStatement("SELECT students.* FROM schedule JOIN students ON schedule.studentid = students.studentid WHERE semester = ? AND coursecode = ? AND status = 's'");
            ps.setString(1, semester);
            ps.setString(2, courseCode);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new StudentEntry(rs.getString("studentid"), rs.getString("firstname"), rs.getString("lastname")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public static ArrayList<StudentEntry> getWaitlistedStudentsByCourse(String semester, String courseCode) {
        ArrayList<StudentEntry> list = new ArrayList<>();
        try {
            PreparedStatement ps = connection.prepareStatement("SELECT students.* FROM schedule JOIN students ON schedule.studentid = students.studentid WHERE semester = ? AND coursecode = ? AND status = 'w' ORDER BY timestamp");
            ps.setString(1, semester);
            ps.setString(2, courseCode);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new StudentEntry(rs.getString("studentid"), rs.getString("firstname"), rs.getString("lastname")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

}
