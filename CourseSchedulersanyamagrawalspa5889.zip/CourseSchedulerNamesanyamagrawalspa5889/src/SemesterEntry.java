/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sanyam_agrawal1
 */
public class SemesterEntry {
    private String year;
    private String term;

    public SemesterEntry(String term, String year) {
        this.term = term;
        this.year = year;
    }

    public String getYear() {
        return year;
    }

    public String getTerm() {
        return term;
    }
    
    @Override
    public String toString() {
        return term + " " + year;
    }
    
}
