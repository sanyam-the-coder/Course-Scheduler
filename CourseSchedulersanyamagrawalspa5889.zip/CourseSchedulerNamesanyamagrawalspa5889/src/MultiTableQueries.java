/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sanyam_agrawal1
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class MultiTableQueries {
    private static Connection connection;
    private static PreparedStatement getAllClassDescriptions;
    private static PreparedStatement getWaitlistedStudentsByClass;
    private static PreparedStatement getScheduledStudentsByClass;
    private static ResultSet resultSet;
    
    
    public static ArrayList<StudentEntry> getScheduledStudentsByClass(String semester, String courseCode) {
        connection = DBConnection.getConnection();
        ArrayList<StudentEntry> students = new ArrayList<>();
        try {
            getScheduledStudentsByClass = connection.prepareStatement(
                "SELECT student.studentID, student.firstName, student.lastName " +
                "FROM schedule JOIN student ON schedule.studentID = student.studentID " +
                "WHERE schedule.semester = ? AND schedule.courseCode = ? AND schedule.status = 'S' " +
                "ORDER BY schedule.timestamp"
            );
            getScheduledStudentsByClass.setString(1, semester);
            getScheduledStudentsByClass.setString(2, courseCode);
            resultSet = getScheduledStudentsByClass.executeQuery();
            while (resultSet.next()) {
                students.add(new StudentEntry(
                    resultSet.getString("studentID"),
                    resultSet.getString("firstName"),
                    resultSet.getString("lastName")
                ));
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return students;
    }

    public static ArrayList<ClassDescription> getAllClassDescriptions(String semester) {
        connection = DBConnection.getConnection();
        ArrayList<ClassDescription> descriptions = new ArrayList<>();
        try {
            getAllClassDescriptions = connection.prepareStatement(
                "SELECT class.courseCode, course.description, class.seats " +
                "FROM class JOIN course ON class.courseCode = course.courseCode " +
                "WHERE class.semester = ? ORDER BY class.courseCode"
            );
            getAllClassDescriptions.setString(1, semester);
            resultSet = getAllClassDescriptions.executeQuery();
            while (resultSet.next()) {
                descriptions.add(new ClassDescription(
                    resultSet.getString("courseCode"),
                    resultSet.getString("description"),
                    resultSet.getInt("seats")
                ));
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return descriptions;
    }


    public static ArrayList<StudentEntry> getWaitlistedStudentsByClass(String semester, String courseCode) {
        connection = DBConnection.getConnection();
        ArrayList<StudentEntry> students = new ArrayList<>();
        try {
            getWaitlistedStudentsByClass = connection.prepareStatement(
                "SELECT student.studentID, student.firstName, student.lastName " +
                "FROM schedule JOIN student ON schedule.studentID = student.studentID " +
                "WHERE schedule.semester = ? AND schedule.courseCode = ? AND schedule.status = 'W' " +
                "ORDER BY schedule.timestamp"
            );
            getWaitlistedStudentsByClass.setString(1, semester);
            getWaitlistedStudentsByClass.setString(2, courseCode);
            resultSet = getWaitlistedStudentsByClass.executeQuery();
            while (resultSet.next()) {
                students.add(new StudentEntry(
                    resultSet.getString("studentID"),
                    resultSet.getString("firstName"),
                    resultSet.getString("lastName")
                ));
            }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
        return students;
    }
}


