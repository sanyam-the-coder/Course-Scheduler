/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author sanyam_agrawal1
 */
public class SemesterQueries {

    private static Connection conn;
    private static ArrayList<String> facultyList = new ArrayList<>();
    private static PreparedStatement stmtAddSemester;
    private static PreparedStatement stmtGetSemesters;
    private static ResultSet rs;

    public static void addSemester(SemesterEntry semester) {
        conn = DBConnection.getConnection();
        try {
            stmtAddSemester = conn.prepareStatement(
                "INSERT INTO semester (semesterTerm, semesterYear) VALUES (?, ?)"
            );
            stmtAddSemester.setString(1, semester.getTerm());
            stmtAddSemester.setString(2, semester.getYear());
            stmtAddSemester.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<SemesterEntry> getSemesterList() {
        conn = DBConnection.getConnection();
        ArrayList<SemesterEntry> semesterEntries = new ArrayList<>();
        try {
            stmtGetSemesters = conn.prepareStatement(
                "SELECT semesterTerm, semesterYear FROM semester ORDER BY semesterYear"
            );
            rs = stmtGetSemesters.executeQuery();
            while (rs.next()) {
                SemesterEntry semester = new SemesterEntry(rs.getString(1), rs.getString(2));
                semesterEntries.add(semester);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return semesterEntries;
    }
}
