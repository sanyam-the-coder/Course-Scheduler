/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sanyam_agrawal1
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ClassQueries {

    private static Connection conn;
    private static PreparedStatement stmtAddClass;
    private static PreparedStatement stmtGetCourseCodes;
    private static PreparedStatement stmtGetSeats;
    private static PreparedStatement stmtDropClass;
    private static ResultSet rs;

    public static void addClass(ClassEntry classEntry) {
        conn = DBConnection.getConnection();
        try {
            stmtAddClass = conn.prepareStatement(
                "INSERT INTO class (semester, courseCode, seats) VALUES (?, ?, ?)"
            );
            stmtAddClass.setString(1, classEntry.getSemester());
            stmtAddClass.setString(2, classEntry.getCourseCode());
            stmtAddClass.setInt(3, classEntry.getSeats());
            stmtAddClass.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public static int getClassSeats(String semester, String courseCode) {
        conn = DBConnection.getConnection();
        int seatCount = 0;
        try {
            stmtGetSeats = conn.prepareStatement(
                "SELECT seats FROM class WHERE semester = ? AND courseCode = ?"
            );
            stmtGetSeats.setString(1, semester);
            stmtGetSeats.setString(2, courseCode);
            rs = stmtGetSeats.executeQuery();
            if (rs.next()) {
                seatCount = rs.getInt("seats");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return seatCount;
    }   

    public static ArrayList<String> getAllCourseCodes(String semester) {
        conn = DBConnection.getConnection();
        ArrayList<String> codes = new ArrayList<>();
        try {
            stmtGetCourseCodes = conn.prepareStatement(
                "SELECT courseCode FROM class WHERE semester = ? ORDER BY courseCode"
            );
            stmtGetCourseCodes.setString(1, semester);
            rs = stmtGetCourseCodes.executeQuery();
            while (rs.next()) {
                codes.add(rs.getString("courseCode"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return codes;
    }



    public static void dropClass(String semester, String courseCode) {
        conn = DBConnection.getConnection();
        try {
            stmtDropClass = conn.prepareStatement(
                "DELETE FROM class WHERE semester = ? AND courseCode = ?"
            );
            stmtDropClass.setString(1, semester);
            stmtDropClass.setString(2, courseCode);
            stmtDropClass.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}