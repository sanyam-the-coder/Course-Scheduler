/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author sanyam_agrawal1
 */
public class ClassEntry {
    
    private int totalSeats;
    private String term;
    private String courseIdentifier;
    
    public ClassEntry(String term, String courseIdentifier, int totalSeats) {
        this.totalSeats = totalSeats;
        this.courseIdentifier = courseIdentifier;
        this.term = term;
    }
      
    public String getCourseCode() {
        return courseIdentifier;
    }
    
    public int getSeats() {
        return totalSeats;
    }    
    
    public String getSemester() {
        return term;
    }
}
