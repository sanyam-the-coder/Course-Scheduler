/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author sanyam_agrawal1
 */
public class ClassDescription { 
    private String classDescription;
    private int availableSeats;
    private String code;
    
    public ClassDescription(String code, String classDescription, int availableSeats) {
        this.classDescription = classDescription;
        this.availableSeats = availableSeats;
        this.code = code;
    }
    
    public int getSeats() {
        return availableSeats;
    }
    
    public String getDescription() {
        return classDescription;
    }
    
    public String getCourseCode() {
        return code;
    }
}
