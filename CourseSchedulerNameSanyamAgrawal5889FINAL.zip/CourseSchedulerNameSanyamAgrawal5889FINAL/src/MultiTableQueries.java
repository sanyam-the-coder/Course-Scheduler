/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sanyam_agrawal1
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class MultiTableQueries {

    private static Connection conn;
    private static PreparedStatement stmtGetAllClassDesc;
    private static PreparedStatement stmtGetScheduledStudents;
    private static PreparedStatement stmtGetWaitlistedStudents;
    private static ResultSet rs;

    public static ArrayList<ClassDescription> getAllClassDescriptions(String semester) {
        conn = DBConnection.getConnection();
        ArrayList<ClassDescription> classList = new ArrayList<>();
        try {
            stmtGetAllClassDesc = conn.prepareStatement(
                "SELECT class.courseCode, course.description, class.seats " +
                "FROM class JOIN course ON class.courseCode = course.courseCode " +
                "WHERE class.semester = ? ORDER BY class.courseCode"
            );
            stmtGetAllClassDesc.setString(1, semester);
            rs = stmtGetAllClassDesc.executeQuery();
            while (rs.next()) {
                classList.add(new ClassDescription(
                    rs.getString("courseCode"),
                    rs.getString("description"),
                    rs.getInt("seats")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return classList;
    }


    public static ArrayList<StudentEntry> getWaitlistedStudentsByClass(String semester, String courseCode) {
        conn = DBConnection.getConnection();
        ArrayList<StudentEntry> students = new ArrayList<>();
        try {
            stmtGetWaitlistedStudents = conn.prepareStatement(
                "SELECT student.studentID, student.firstName, student.lastName " +
                "FROM schedule JOIN student ON schedule.studentID = student.studentID " +
                "WHERE schedule.semester = ? AND schedule.courseCode = ? AND schedule.status = 'W' " +
                "ORDER BY schedule.timestamp"
            );
            stmtGetWaitlistedStudents.setString(1, semester);
            stmtGetWaitlistedStudents.setString(2, courseCode);
            rs = stmtGetWaitlistedStudents.executeQuery();
            while (rs.next()) {
                students.add(new StudentEntry(
                    rs.getString("studentID"),
                    rs.getString("firstName"),
                    rs.getString("lastName")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }
    
    
    public static ArrayList<StudentEntry> getScheduledStudentsByClass(String semester, String courseCode) {
        conn = DBConnection.getConnection();
        ArrayList<StudentEntry> students = new ArrayList<>();
        try {
            stmtGetScheduledStudents = conn.prepareStatement(
                "SELECT student.studentID, student.firstName, student.lastName " +
                "FROM schedule JOIN student ON schedule.studentID = student.studentID " +
                "WHERE schedule.semester = ? AND schedule.courseCode = ? AND schedule.status = 'S' " +
                "ORDER BY schedule.timestamp"
            );
            stmtGetScheduledStudents.setString(1, semester);
            stmtGetScheduledStudents.setString(2, courseCode);
            rs = stmtGetScheduledStudents.executeQuery();
            while (rs.next()) {
                students.add(new StudentEntry(
                    rs.getString("studentID"),
                    rs.getString("firstName"),
                    rs.getString("lastName")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }
}
