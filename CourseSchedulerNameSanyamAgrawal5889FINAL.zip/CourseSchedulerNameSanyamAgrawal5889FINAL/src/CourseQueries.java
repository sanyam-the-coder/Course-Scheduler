/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sanyam_agrawal1
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class CourseQueries {

    private static Connection conn;
    private static PreparedStatement stmtAddCourse;
    private static PreparedStatement stmtGetCourseCodes;
    private static ResultSet rs;
    
    
    public static ArrayList<String> getAllCourseCodes() {
        conn = DBConnection.getConnection();
        ArrayList<String> codes = new ArrayList<>();
        try {
            stmtGetCourseCodes = conn.prepareStatement(
                "SELECT courseCode FROM course ORDER BY courseCode"
            );
            rs = stmtGetCourseCodes.executeQuery();
            while (rs.next()) {
                codes.add(rs.getString("courseCode"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return codes;
    }    

    public static void addCourse(CourseEntry course) {
        conn = DBConnection.getConnection();
        try {
            stmtAddCourse = conn.prepareStatement(
                "INSERT INTO course (courseCode, description) VALUES (?, ?)"
            );
            stmtAddCourse.setString(1, course.getCourseCode());
            stmtAddCourse.setString(2, course.getDescription());
            stmtAddCourse.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
