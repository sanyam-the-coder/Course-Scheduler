/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sanyam_agrawal1
 */
import java.sql.Timestamp;

public class ScheduleEntry {

    private String term;
    private String courseCode;
    private String studentId;
    private String enrollmentStatus; 
    private Timestamp recordTime;

    public ScheduleEntry(String term, String courseCode, String studentId, String enrollmentStatus, Timestamp recordTime) {
        this.term = term;
        this.courseCode = courseCode;
        this.studentId = studentId;
        this.enrollmentStatus = enrollmentStatus;
        this.recordTime = recordTime;
    }

    public String getSemester() {
        return term;
    }

    public String getStudentID() {
        return studentId;
    }
    
    public String getCourseCode() {
        return courseCode;
    }

    public String getStatus() {
        return enrollmentStatus;
    }

    public Timestamp getTimestamp() {
        return recordTime;
    }
}
