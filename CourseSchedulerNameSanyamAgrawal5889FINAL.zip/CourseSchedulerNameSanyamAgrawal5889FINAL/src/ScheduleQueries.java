/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sanyam_agrawal1
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

public class ScheduleQueries {

    private static Connection conn;
    private static PreparedStatement stmtAddEntry;
    private static PreparedStatement stmtGetStudentSchedule;
    private static PreparedStatement stmtGetScheduledCount;
    private static PreparedStatement stmtGetWaitlistByClass;
    private static PreparedStatement stmtDropStudentCourse;
    private static PreparedStatement stmtDropCourseSchedule;
    private static PreparedStatement stmtUpdateEntry;
    private static PreparedStatement stmtDropStudentAllSchedules;
    private static PreparedStatement stmtGetAllStudentSchedules;
    private static ResultSet rs;

    public static void addScheduleEntry(ScheduleEntry entry) {
        conn = DBConnection.getConnection();
        try {
            stmtAddEntry = conn.prepareStatement(
                "INSERT INTO schedule (semester, courseCode, studentID, status, timestamp) VALUES (?, ?, ?, ?, ?)"
            );
            stmtAddEntry.setString(1, entry.getSemester());
            stmtAddEntry.setString(2, entry.getCourseCode());
            stmtAddEntry.setString(3, entry.getStudentID());
            stmtAddEntry.setString(4, entry.getStatus());
            stmtAddEntry.setTimestamp(5, entry.getTimestamp());
            stmtAddEntry.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<ScheduleEntry> getScheduleByStudent(String semester, String studentID) {
        conn = DBConnection.getConnection();
        ArrayList<ScheduleEntry> scheduleList = new ArrayList<>();
        try {
            stmtGetStudentSchedule = conn.prepareStatement(
                "SELECT * FROM schedule WHERE semester = ? AND studentID = ?"
            );
            stmtGetStudentSchedule.setString(1, semester);
            stmtGetStudentSchedule.setString(2, studentID);
            rs = stmtGetStudentSchedule.executeQuery();
            while (rs.next()) {
                scheduleList.add(new ScheduleEntry(
                    rs.getString("semester"),
                    rs.getString("courseCode"),
                    rs.getString("studentID"),
                    rs.getString("status"),
                    rs.getTimestamp("timestamp")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return scheduleList;
    }

    public static ArrayList<ScheduleEntry> getWaitlistedStudentsByClass(String semester, String courseCode) {
        conn = DBConnection.getConnection();
        ArrayList<ScheduleEntry> waitlist = new ArrayList<>();
        try {
            stmtGetWaitlistByClass = conn.prepareStatement(
                "SELECT * FROM schedule WHERE semester = ? AND courseCode = ? AND status = 'W' ORDER BY timestamp"
            );
            stmtGetWaitlistByClass.setString(1, semester);
            stmtGetWaitlistByClass.setString(2, courseCode);
            rs = stmtGetWaitlistByClass.executeQuery();
            while (rs.next()) {
                waitlist.add(new ScheduleEntry(
                    rs.getString("semester"),
                    rs.getString("courseCode"),
                    rs.getString("studentID"),
                    rs.getString("status"),
                    rs.getTimestamp("timestamp")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return waitlist;
    }
    
    
    public static int getScheduledStudentCount(String semester, String courseCode) {
        conn = DBConnection.getConnection();
        int count = 0;
        try {
            stmtGetScheduledCount = conn.prepareStatement(
                "SELECT COUNT(*) FROM schedule WHERE semester = ? AND courseCode = ? AND status = 'S'"
            );
            stmtGetScheduledCount.setString(1, semester);
            stmtGetScheduledCount.setString(2, courseCode);
            rs = stmtGetScheduledCount.executeQuery();
            if (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }    

    public static void dropStudentScheduleByCourse(String semester, String studentID, String courseCode) {
        conn = DBConnection.getConnection();
        try {
            stmtDropStudentCourse = conn.prepareStatement(
                "DELETE FROM schedule WHERE semester = ? AND studentID = ? AND courseCode = ?"
            );
            stmtDropStudentCourse.setString(1, semester);
            stmtDropStudentCourse.setString(2, studentID);
            stmtDropStudentCourse.setString(3, courseCode);
            stmtDropStudentCourse.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void dropScheduleByCourse(String semester, String courseCode) {
        conn = DBConnection.getConnection();
        try {
            stmtDropCourseSchedule = conn.prepareStatement(
                "DELETE FROM schedule WHERE semester = ? AND courseCode = ?"
            );
            stmtDropCourseSchedule.setString(1, semester);
            stmtDropCourseSchedule.setString(2, courseCode);
            stmtDropCourseSchedule.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updateScheduleEntry(ScheduleEntry entry) {
        conn = DBConnection.getConnection();
        try {
            stmtUpdateEntry = conn.prepareStatement(
                "UPDATE schedule SET status = ?, timestamp = ? WHERE semester = ? AND courseCode = ? AND studentID = ?"
            );
            stmtUpdateEntry.setString(1, entry.getStatus());
            stmtUpdateEntry.setTimestamp(2, entry.getTimestamp());
            stmtUpdateEntry.setString(3, entry.getSemester());
            stmtUpdateEntry.setString(4, entry.getCourseCode());
            stmtUpdateEntry.setString(5, entry.getStudentID());
            stmtUpdateEntry.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void dropStudentAllSchedules(String studentID) {
        conn = DBConnection.getConnection();
        try {
            stmtDropStudentAllSchedules = conn.prepareStatement(
                "DELETE FROM schedule WHERE studentID = ?"
            );
            stmtDropStudentAllSchedules.setString(1, studentID);
            stmtDropStudentAllSchedules.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<ScheduleEntry> getAllSchedulesByStudent(String studentID) {
        conn = DBConnection.getConnection();
        ArrayList<ScheduleEntry> scheduleList = new ArrayList<>();
        try {
            stmtGetAllStudentSchedules = conn.prepareStatement(
                "SELECT * FROM schedule WHERE studentID = ? ORDER BY semester"
            );
            stmtGetAllStudentSchedules.setString(1, studentID);
            rs = stmtGetAllStudentSchedules.executeQuery();
            while (rs.next()) {
                scheduleList.add(new ScheduleEntry(
                    rs.getString("semester"),
                    rs.getString("courseCode"),
                    rs.getString("studentID"),
                    rs.getString("status"),
                    rs.getTimestamp("timestamp")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return scheduleList;
    }
}