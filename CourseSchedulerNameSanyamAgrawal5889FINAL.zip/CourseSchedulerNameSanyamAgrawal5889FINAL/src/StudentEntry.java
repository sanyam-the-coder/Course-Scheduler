/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sanyam_agrawal1
 */
public class StudentEntry {

    private String id;
    private String givenName;
    private String familyName;

    public StudentEntry(String id, String givenName, String familyName) {
        this.id = id;
        this.givenName = givenName;
        this.familyName = familyName;
    }
    
    public String getFirstName() {
        return givenName;
    }    

    public String getStudentID() {
        return id;
    }

    public String getLastName() {
        return familyName;
    }

    @Override
    public String toString() {
        return givenName + " " + familyName;
    }
}
