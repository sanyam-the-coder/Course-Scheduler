/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sanyam_agrawal1
 */
public class SemesterEntry {

    private String semesterTerm;
    private String academicYear;

    public SemesterEntry(String semesterTerm, String academicYear) {
        this.semesterTerm = semesterTerm;
        this.academicYear = academicYear;
    }
    
    public String getTerm() {
        return semesterTerm;
    }    

    public String getYear() {
        return academicYear;
    }


    @Override
    public String toString() {
        return semesterTerm + " " + academicYear;
    }
}
